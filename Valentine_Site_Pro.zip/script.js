
function checkPassword() {
    const pass = document.getElementById("password").value;
    if(pass === "18/06/22") {
        window.location.href = "page2.html";
    } else {
        document.getElementById("error").innerText = "Wrong date ❤️";
    }
}

const text = "From the first heartbeat, my world changed because of you. Every smile, every memory, every second with you is the most beautiful chapter of my life.";

let i = 0;
function typeWriter() {
    if (document.getElementById("typewriter") && i < text.length) {
        document.getElementById("typewriter").innerHTML += text.charAt(i);
        i++;
        setTimeout(typeWriter, 40);
    } else if(document.getElementById("startBtn")) {
        document.getElementById("startBtn").style.display = "inline-block";
    }
}

if(document.getElementById("typewriter")) typeWriter();

function goToMemories(){
    window.location.href = "memories.html";
}

function goToLetter(){
    window.location.href = "letter.html";
}

const letter = "My love, since 18 June 2022, time has not just passed... it has blossomed. Every day with you is a blessing I thank destiny for. You are my forever, my always, my everything.";

let j = 0;
function typeLetter() {
    if (document.getElementById("letterText") && j < letter.length) {
        document.getElementById("letterText").innerHTML += letter.charAt(j);
        j++;
        setTimeout(typeLetter, 40);
    }
}

if(document.getElementById("letterText")) typeLetter();

function updateCounter() {
    const startDate = new Date("June 18, 2022 00:00:00").getTime();
    const now = new Date().getTime();
    const diff = now - startDate;

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
    const minutes = Math.floor((diff / (1000 * 60)) % 60);
    const seconds = Math.floor((diff / 1000) % 60);

    const counter = document.getElementById("counter");
    if(counter){
        counter.innerHTML = `Time since 18 June 2022: ${days} days ${hours} hours ${minutes} minutes ${seconds} seconds`;
    }
}

setInterval(updateCounter, 1000);
